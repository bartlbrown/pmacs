def pi():
    return (u'pmacs lives.')
